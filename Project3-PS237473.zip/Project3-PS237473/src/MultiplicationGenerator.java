import javax.swing.JOptionPane;
public class MultiplicationGenerator {
	public static void RandomQuestionGenerator(){
		int number1 = (int)(Math.random()*8)+1;//Generating First Random Number
		int number2 = (int)(Math.random()*8)+1;//Generating Second Random Number
		String question = number1 +" "+"times"+" " + number2+" " + "equals to?";
		int multiplication = number1 * number2; //Storing number1 times number2 value for calculation in a variable called multiplication
		
		
		do{
			JOptionPane.showMessageDialog(null,question,"Question for you",JOptionPane.QUESTION_MESSAGE);
			String newanswer = JOptionPane.showInputDialog(null,"Enter an answer(numbers only) to the multiplication:",question,JOptionPane.PLAIN_MESSAGE);
			int answer = Integer.parseInt(newanswer);//Converting String answer to Integer
			if(newanswer != null && answer==multiplication){//Condition checking - Making sure that user will not provide null value to calculation
				JOptionPane.showMessageDialog(null,"Right/corect Answer","Information",JOptionPane.INFORMATION_MESSAGE);
				break;
			}JOptionPane.showMessageDialog(null,"Error! The Entered Value is not Correct"," Try Again with different answer", JOptionPane.ERROR_MESSAGE);
			
		}while(true);
	}
	
   public static void main(String args[]){
	  do{
		  RandomQuestionGenerator();
		  String choice = JOptionPane.showInputDialog(null,"Do you want to try another question? (Y/N)","Question for you",JOptionPane.QUESTION_MESSAGE);
		  if (!choice.equalsIgnoreCase("Y")){
		  		break;
		  }		
	   }while(true);
	  JOptionPane.showMessageDialog(null,"Thank you so much!"," See You Again",JOptionPane.INFORMATION_MESSAGE); 
   }
}
